import os
import json
import requests
from flask import Flask, request, jsonify
from flask_cors import CORS
import base64
from datetime import datetime
from PIL import Image
import numpy as np
import io
import tensorflow as tf
from dotenv import load_dotenv


os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'


load_dotenv()

app = Flask(__name__)
CORS(app)


IMAGE_DATA_FILE = 'app/image_data.json'
SENSOR_DATA_FILE = 'app/sensor_data.json'
IMAGES_FOLDER = 'app/images'
OPENWEATHERMAP_API_KEY = os.getenv('OPENWEATHERMAP_API_KEY')
AIRVISUAL_API_KEY = os.getenv('AIRVISUAL_API_KEY')

def load_image_data():
    if os.path.exists(IMAGE_DATA_FILE):
        with open(IMAGE_DATA_FILE, 'r') as file:
            return json.load(file)
    return []

def load_sensor_data():
    if os.path.exists(SENSOR_DATA_FILE):
        with open(SENSOR_DATA_FILE, 'r') as file:
            return json.load(file)
    return []

def save_image_data(data):
    with open(IMAGE_DATA_FILE, 'w') as file:
        json.dump(data, file, indent=4)

def save_sensor_data(data):
    with open(SENSOR_DATA_FILE, 'w') as file:
        json.dump(data, file, indent=4)

if not os.path.exists(IMAGES_FOLDER):
    os.makedirs(IMAGES_FOLDER)

def get_weather_data_by_city(city):
    weather_url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={OPENWEATHERMAP_API_KEY}&units=metric'
    print(f"Requesting weather data for city: {city}")
    response = requests.get(weather_url)
    print(f"Weather API response status code: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"Weather data received: {data}")
        return {
            "temperature": data["main"]["temp"],
            "humidity": data["main"]["humidity"]
        }
    else:
        print(f"Failed to get weather data: {response.text}")
        return None

def get_air_quality_data_by_city(city):
    air_quality_url = f'http://api.airvisual.com/v2/city?city={city}&key={AIRVISUAL_API_KEY}'
    print(f"Requesting air quality data for city: {city}")
    response = requests.get(air_quality_url)
    print(f"Air Quality API response status code: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"Air quality data received: {data}")
        return {
            "air_quality": data["data"]["current"]["pollution"]["aqius"]
        }
    else:
        print(f"Failed to get air quality data: {response.text}")
        return None

@app.route('/upload-image', methods=['POST'])
def upload_image():
    file = request.files.get('image')
    if not file:
        return jsonify({"error": "No image provided"}), 400

    image_id = datetime.now().strftime('%Y%m%d%H%M%S')
    image_data = base64.b64encode(file.read()).decode('utf-8')

    image_entry = {
        "id": image_id,
        "base64": image_data,
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "location": request.form.get('location', 'Unknown'),
            "description": request.form.get('description', '')
        }
    }

    data = load_image_data()
    data.append(image_entry)
    save_image_data(data)

    print(f"Image uploaded with ID: {image_id}")
    return jsonify({"image_id": image_id}), 201

@app.route('/sensor-data', methods=['POST'])
def sensor_data():
    sensor_data = request.json
    if not sensor_data:
        return jsonify({"error": "No sensor data provided"}), 400

    city_or_country = sensor_data.get('location')
    if not city_or_country:
        return jsonify({"error": "Location data not provided"}), 400

    print(f"Processing sensor data for location: {city_or_country}")

    weather_data = get_weather_data_by_city(city_or_country)
    air_quality_data = get_air_quality_data_by_city(city_or_country)

    if not weather_data or not air_quality_data:
        return jsonify({"error": "Failed to retrieve weather or air quality data"}), 500

    sensor_data_entry = {
        "id": datetime.now().strftime('%Y%m%d%H%M%S'),
        "timestamp": datetime.now().isoformat(),
        "location": city_or_country,
        "temperature": weather_data["temperature"],
        "humidity": weather_data["humidity"],
        "air_quality": air_quality_data["air_quality"]
    }

    data = load_sensor_data()
    data.append(sensor_data_entry)
    save_sensor_data(data)

    print(f"Sensor data saved for location: {city_or_country}, Data: {sensor_data_entry}")
    return jsonify({"status": "success", "data": sensor_data_entry}), 201

@app.route('/data', methods=['GET'])
def get_data():
    data_type = request.args.get('type')
    if data_type == 'images':
        print("Fetching all image data")
        return jsonify(load_image_data())
    elif data_type == 'sensor_data':
        print("Fetching all sensor data")
        return jsonify(load_sensor_data())
    else:
        print("Fetching all data")
        return jsonify({
            "images": load_image_data(),
            "sensor_data": load_sensor_data()
        }), 200
@app.route('/')
def index():
    return jsonify({"message": "Welcome to the Flask app!"})

if __name__ == '__main__':
    app.run(debug=True)
